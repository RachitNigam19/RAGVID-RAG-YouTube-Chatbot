import streamlit as st

def show_home():
    st.title("🎬 VidRAG: Ask Anything from YouTube Videos")

    # Input: YouTube URL
    url = st.text_input("Enter YouTube Video URL")

    if url:
        st.video(url)  # simple video player

        query = st.text_input("Ask a question about this video")
        if query:
            # Placeholder for LLM logic
            st.success(f"🤖 Answer for: {query}")
            # Save to history
            if "history" not in st.session_state:
                st.session_state.history = []
            st.session_state.history.append({"video": url, "query": query, "answer": "Sample Answer"})
