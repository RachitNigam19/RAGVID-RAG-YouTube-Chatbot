import streamlit as st

def show_history():
    st.title("📜 Your Past Queries")

    if "history" in st.session_state and st.session_state.history:
        for idx, item in enumerate(st.session_state.history, 1):
            st.markdown(f"**{idx}. Video:** {item['video']}")
            st.markdown(f"- ❓ **Query:** {item['query']}")
            st.markdown(f"- 🤖 **Answer:** {item['answer']}")
            st.divider()
    else:
        st.info("No history found. Ask something in the Home page first!")
