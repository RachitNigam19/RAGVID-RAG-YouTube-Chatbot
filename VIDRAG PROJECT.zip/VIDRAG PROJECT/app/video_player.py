# # Script to fetch video id and play video on web 

# # import dependencies 
# import streamlit as st 
# import re 

# app/video_player.py
import re
from urllib.parse import urlparse, parse_qs

def extract_video_id(url: str) -> str:
    """
    Extract YouTube video ID from various URL formats
    Supports:
    - https://www.youtube.com/watch?v=VIDEO_ID
    - https://youtu.be/VIDEO_ID
    - https://youtube.com/watch?v=VIDEO_ID
    - https://m.youtube.com/watch?v=VIDEO_ID
    """
    try:
        # Remove any extra whitespace
        url = url.strip()
        
        # Handle youtu.be short URLs
        if "youtu.be/" in url:
            video_id = url.split("youtu.be/")[1].split("?")[0].split("&")[0]
            return video_id
        
        # Handle regular YouTube URLs
        if "youtube.com/watch" in url or "youtube.com/v/" in url:
            # Parse the URL
            parsed_url = urlparse(url)
            
            # Extract from query parameters
            if "watch" in parsed_url.path:
                query_params = parse_qs(parsed_url.query)
                if 'v' in query_params:
                    return query_params['v'][0]
            
            # Extract from /v/ path
            if "/v/" in parsed_url.path:
                video_id = parsed_url.path.split("/v/")[1].split("?")[0]
                return video_id
        
        # Regex fallback for any YouTube URL
        patterns = [
            r'(?:youtube\.com\/(?:[^\/]+\/.+\/|(?:v|e(?:mbed)?)\/|.*[?&]v=)|youtu\.be\/)([^"&?\/\s]{11})',
            r'youtube\.com\/watch\?v=([^&\n?#]+)',
            r'youtu\.be\/([^&\n?#]+)'
        ]
        
        for pattern in patterns:
            match = re.search(pattern, url)
            if match:
                return match.group(1)
        
        print(f"❌ Could not extract video ID from URL: {url}")
        return None
        
    except Exception as e:
        print(f"❌ Error extracting video ID: {e}")
        return None


# def extract_video_id(url:str) -> str:
#               # fetches video id from the url
#               pattern = r"(?:v=|youtu\.be/)([a-zA-Z0-9_-]{11})"
#               match = re.search(pattern, url)
#               if match:
#                       return match.group(1)
#               return None

# def show_video(url:str):
#         # play video on streamlit 
#         video_id = extract_video_id(url)
#         if video_id:
#                 embed_url = f"https://www.youtube.com/embed/{video_id}"
#                 st.markdown(
#                         f"""
#                         <iframe width="700" height="400"
#                         src="{embed_url}"
#                         frameborder="0"
#                         allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
#                         allowfullscreen>
#                         </iframe>
#                         """,
#                         unsafe_allow_html=True
#                         )
#         else:
#                 st.error("❌ Invalid YouTube URL. Please try again.")