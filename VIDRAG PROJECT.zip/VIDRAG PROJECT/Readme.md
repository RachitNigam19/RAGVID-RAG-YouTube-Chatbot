VidRAG/
│
├── app/                        # Streamlit frontend
│   ├── __init__.py
│   ├── main.py                 # Entry point for Streamlit app
│   ├── pages/                  # Optional multipage app
│   │   ├── home.py
│   │   └── history.py
│   └── components/             # Custom Streamlit UI components
│       └── video_player.py
│
├── backend/                    # LLM & RAG backend
│   ├── __init__.py
│   ├── llm.py                  # LLM wrapper / inference code
│   ├── rag_engine.py           # Retrieval + chat logic
│   ├── youtube.py              # YouTube video processing / transcript fetching
│   └── embeddings.py           # Embedding generation & storage
│
├── data/                       # All stored data
│   ├── raw/                    # Raw transcripts (JSON from YouTube)
│   ├── processed/              # Processed, cleaned transcripts
│   └── embeddings/             # Generated embeddings for RAG
│
├── utils/                      # Utility scripts
│   ├── __init__.py
│   ├── file_ops.py             # Save/load JSON, CSV, etc.
│   ├── text_cleaning.py        # Preprocessing helper functions
│   └── logger.py               # Logging
│
├── tests/                      # Unit & integration tests
│   ├── test_backend.py
│   └── test_utils.py
│
├── requirements.txt            # Python dependencies
├── README.md                   # Project overview
└── .gitignore                  # Ignore virtual env, data, etc.
