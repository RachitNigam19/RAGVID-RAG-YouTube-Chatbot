# main.py - VidRAG: YouTube Video QnA Application
import streamlit as st
from backend.rag_engine import chaining
from app.video_player import extract_video_id
import asyncio
import nest_asyncio
import re
import time
from datetime import datetime

# ✅ Fix asyncio event loop for Streamlit compatibility
try:
    asyncio.get_running_loop()
except RuntimeError:
    asyncio.set_event_loop(asyncio.new_event_loop())

nest_asyncio.apply()

# App configuration
st.set_page_config(
    page_title="VidRAG - YouTube Video QnA",
    page_icon="🎬",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS for better UI
st.markdown("""
<style>
    .main-header {
        font-size: 3rem;
        font-weight: bold;
        text-align: center;
        background: linear-gradient(90deg, #FF6B6B, #4ECDC4);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        margin-bottom: 1rem;
    }
    
    .chat-message {
        padding: 1rem;
        border-radius: 10px;
        margin: 0.5rem 0;
        border-left: 4px solid #4ECDC4;
        background-color: #f8f9fa;
    }
    
    .user-message {
        border-left-color: #FF6B6B;
        background-color: #fff5f5;
    }
    
    .bot-message {
        border-left-color: #4ECDC4;
        background-color: #f0fffe;
    }
    
    .error-message {
        border-left-color: #ff4444;
        background-color: #ffe6e6;
        color: #cc0000;
    }
    
    .success-message {
        border-left-color: #44ff44;
        background-color: #e6ffe6;
        color: #006600;
    }
    
    .video-info {
        background-color: #f0f2f6;
        padding: 1rem;
        border-radius: 10px;
        margin: 1rem 0;
    }
</style>
""", unsafe_allow_html=True)

# Initialize session state
def init_session_state():
    """Initialize all session state variables"""
    session_defaults = {
        "chat_history": [],
        "video_url": "",
        "video_id": "",
        "video_processed": False,
        "processing_status": "",
        "total_messages": 0,
        "session_start_time": datetime.now()
    }
    
    for key, default_value in session_defaults.items():
        if key not in st.session_state:
            st.session_state[key] = default_value

def validate_youtube_url(url: str) -> tuple[bool, str]:
    """
    Validate if the provided URL is a valid YouTube URL
    Returns: (is_valid: bool, message: str)
    """
    if not url:
        return False, "Please enter a YouTube URL"
    
    youtube_patterns = [
        r'(https?://)?(www\.)?(youtube|youtu|youtube-nocookie)\.(com|be)/',
        r'(https?://)?(m\.)?youtube\.com/',
    ]
    
    is_valid = any(re.search(pattern, url.lower()) for pattern in youtube_patterns)
    
    if not is_valid:
        return False, "Please enter a valid YouTube URL"
    
    # Try to extract video ID
    video_id = extract_video_id(url)
    if not video_id:
        return False, "Could not extract video ID from URL"
    
    return True, f"Valid YouTube URL (Video ID: {video_id})"

def clear_chat_history():
    """Clear chat history and reset video processing status"""
    st.session_state.chat_history = []
    st.session_state.video_processed = False
    st.session_state.processing_status = ""
    st.session_state.total_messages = 0

def display_chat_message(role: str, message: str, timestamp: str = None):
    """Display a formatted chat message"""
    if timestamp is None:
        timestamp = datetime.now().strftime("%H:%M:%S")
    
    if role == "user":
        st.markdown(f"""
        <div class="chat-message user-message">
            <strong>👤 You</strong> <span style="font-size: 0.8em; color: #666;">({timestamp})</span><br>
            {message}
        </div>
        """, unsafe_allow_html=True)
    else:
        st.markdown(f"""
        <div class="chat-message bot-message">
            <strong>🤖 VidRAG</strong> <span style="font-size: 0.8em; color: #666;">({timestamp})</span><br>
            {message}
        </div>
        """, unsafe_allow_html=True)

def show_processing_status(status: str, is_error: bool = False):
    """Show processing status with appropriate styling"""
    css_class = "error-message" if is_error else "success-message"
    st.markdown(f"""
    <div class="chat-message {css_class}">
        <strong>{'⚠️ Status' if is_error else '✅ Status'}:</strong> {status}
    </div>
    """, unsafe_allow_html=True)

# Initialize session state
init_session_state()

# Sidebar
with st.sidebar:
    st.title("📂 Navigation")
    page = st.radio("Go to", ["🏠 Home", "📜 History", "⚙️ Settings"])
    
    st.markdown("---")
    
    # Statistics
    st.markdown("### 📊 Session Stats")
    st.metric("Messages Sent", st.session_state.total_messages)
    st.metric("Videos Processed", 1 if st.session_state.video_processed else 0)
    
    # Session info
    session_duration = datetime.now() - st.session_state.session_start_time
    st.metric("Session Duration", f"{session_duration.seconds // 60}m {session_duration.seconds % 60}s")

# ==================== HOME PAGE ==================== #
if page == "🏠 Home":
    # Main title with custom styling
    st.markdown('<h1 class="main-header">🎬 VidRAG</h1>', unsafe_allow_html=True)
    st.markdown("""
    <div style="text-align: center; font-size: 1.2rem; margin-bottom: 2rem; color: #666;">
        Ask anything from YouTube videos using AI-powered transcript analysis
    </div>
    """, unsafe_allow_html=True)

    # Input section
    col1, col2 = st.columns([3, 1])
    
    with col1:
        youtube_url = st.text_input(
            "🔗 Enter YouTube Video URL",
            value=st.session_state.video_url,
            placeholder="https://www.youtube.com/watch?v=..."
        )
    
    with col2:
        st.markdown("<br>", unsafe_allow_html=True)  # Spacing
        clear_button = st.button("🗑️ Clear", help="Clear current video and chat history")
    
    # Handle clear button
    if clear_button:
        st.session_state.video_url = ""
        clear_chat_history()
        st.rerun()

    # URL validation and processing
    if youtube_url:
        if youtube_url != st.session_state.video_url:
            # New URL entered
            st.session_state.video_url = youtube_url
            st.session_state.video_id = extract_video_id(youtube_url)
            clear_chat_history()  # Clear chat when new video is loaded
        
        # Validate URL
        is_valid, validation_message = validate_youtube_url(youtube_url)
        
        if is_valid:
            # Show video player
            try:
                st.video(youtube_url)
                
                # Video information
                st.markdown(f"""
                <div class="video-info">
                    <strong>📹 Video ID:</strong> {st.session_state.video_id}<br>
                    <strong>🔗 URL:</strong> <a href="{youtube_url}" target="_blank">Open in YouTube</a>
                </div>
                """, unsafe_allow_html=True)
                
            except Exception as e:
                show_processing_status(f"Could not load video player: {str(e)}", is_error=True)

            # Chat section
            st.markdown("### 💬 Chat with the Video")
            
            # Chat history display
            chat_container = st.container()
            with chat_container:
                if st.session_state.chat_history:
                    for role, msg, timestamp in st.session_state.chat_history:
                        display_chat_message(role, msg, timestamp)
                else:
                    st.info("👋 Start by asking a question about the video content!")

            # User input
            user_query = st.chat_input("Type your question about this video...")

            if user_query:
                # Add user message with timestamp
                timestamp = datetime.now().strftime("%H:%M:%S")
                st.session_state.chat_history.append(("user", user_query, timestamp))
                st.session_state.total_messages += 1

                # Show processing status
                with st.spinner("🔄 Processing your question..."):
                    status_placeholder = st.empty()
                    
                    try:
                        # Update status
                        status_placeholder.info("📥 Analyzing transcript...")
                        
                        # Call RAG Engine
                        response = chaining(youtube_url, user_query)
                        
                        # Check for error responses
                        if "❌" in response and ("Error" in response or "Failed" in response):
                            show_processing_status(response, is_error=True)
                            response = "I encountered an issue processing your request. Please try again or check if the video has available transcripts."
                        else:
                            status_placeholder.success("✅ Response generated!")
                            st.session_state.video_processed = True
                        
                        # Add bot response with timestamp
                        bot_timestamp = datetime.now().strftime("%H:%M:%S")
                        st.session_state.chat_history.append(("bot", response, bot_timestamp))
                        
                        # Clear status after 2 seconds
                        time.sleep(1)
                        status_placeholder.empty()
                        
                    except Exception as e:
                        error_msg = f"An unexpected error occurred: {str(e)}"
                        show_processing_status(error_msg, is_error=True)
                        
                        bot_timestamp = datetime.now().strftime("%H:%M:%S")
                        st.session_state.chat_history.append(("bot", "I apologize, but I encountered an error processing your request. Please try again.", bot_timestamp))

                # Rerun to update chat display
                st.rerun()
        
        else:
            # Invalid URL
            st.error(validation_message)

# ==================== HISTORY PAGE ==================== #
elif page == "📜 History":
    st.title("📜 Chat History")
    
    if st.session_state.chat_history:
        # Export options
        col1, col2, col3 = st.columns([1, 1, 2])
        
        with col1:
            if st.button("📥 Export Chat"):
                # Create downloadable text file
                chat_text = f"VidRAG Chat History - {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n"
                chat_text += f"Video URL: {st.session_state.video_url}\n"
                chat_text += "=" * 50 + "\n\n"
                
                for role, msg, timestamp in st.session_state.chat_history:
                    role_name = "You" if role == "user" else "VidRAG"
                    chat_text += f"[{timestamp}] {role_name}: {msg}\n\n"
                
                st.download_button(
                    label="💾 Download Chat History",
                    data=chat_text,
                    file_name=f"vidrag_chat_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt",
                    mime="text/plain"
                )
        
        with col2:
            if st.button("🗑️ Clear History"):
                clear_chat_history()
                st.success("Chat history cleared!")
                st.rerun()
        
        # Display chat history
        st.markdown("---")
        for role, msg, timestamp in st.session_state.chat_history:
            display_chat_message(role, msg, timestamp)
    
    else:
        st.info("📝 No chat history available yet. Start chatting from the Home page!")

# ==================== SETTINGS PAGE ==================== #
elif page == "⚙️ Settings":
    st.title("⚙️ Settings")
    
    st.markdown("### 🔧 Application Settings")
    
    # Theme settings (placeholder for future implementation)
    st.markdown("#### 🎨 Display Options")
    show_timestamps = st.checkbox("Show message timestamps", value=True)
    show_video_info = st.checkbox("Show video information", value=True)
    
    st.markdown("#### 📊 Performance Options")
    max_history = st.slider("Maximum chat history messages", 10, 100, 50)
    
    st.markdown("#### 🔄 Reset Options")
    col1, col2 = st.columns(2)
    
    with col1:
        if st.button("🔄 Reset Session"):
            # Reset all session state
            for key in list(st.session_state.keys()):
                del st.session_state[key]
            init_session_state()
            st.success("Session reset successfully!")
            st.rerun()
    
    with col2:
        if st.button("🧹 Clear Cache"):
            st.cache_data.clear()
            st.success("Cache cleared successfully!")
    
    st.markdown("---")
    st.markdown("### ℹ️ About VidRAG")
    st.info("""
    **VidRAG** is an AI-powered application that allows you to ask questions about YouTube videos using their transcripts.
    
    **Features:**
    - 🎬 Support for YouTube video analysis
    - 🤖 AI-powered question answering
    - 💬 Interactive chat interface
    - 📜 Chat history management
    - 📥 Export functionality
    
    **Version:** 1.0.0
    """)

# Footer
st.markdown("---")
st.markdown("""
<div style="text-align: center; color: #666; padding: 1rem;">
    Made with ❤️ using Streamlit | VidRAG v1.0.0
</div>
""", unsafe_allow_html=True)