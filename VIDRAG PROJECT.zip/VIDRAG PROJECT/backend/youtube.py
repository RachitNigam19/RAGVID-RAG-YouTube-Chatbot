# # script to load the transcript of the youtube videos
# from youtube_transcript_api import YouTubeTranscriptApi
# from app.video_player import extract_video_id
# import json

# backend/youtube.py
# Script to load the transcript of the YouTube videos
from youtube_transcript_api import YouTubeTranscriptApi
from app.video_player import extract_video_id
import json
import os

def youtube_transcript_loader(url: str):
    """
    Downloads YouTube transcript in English or Hindi and saves as JSON
    Returns the file path if successful, None if failed
    """
    try:
        target_lang_eng = ['en']
        target_lang_hindi = ['hi']
        
        # Extract video ID
        video_id = extract_video_id(url)
        if not video_id:
            print("❌ Could not extract video ID from URL")
            return None
            
        print(f"📹 Processing video ID: {video_id}")
        
        # Create directory if it doesn't exist
        raw_data_dir = "/home/rachit/Desktop/VIDRAG PROJECT/data/raw"
        os.makedirs(raw_data_dir, exist_ok=True)
        
        # File path for saving
        file_path = os.path.join(raw_data_dir, video_id)
        
        # Check if transcript already exists
        if os.path.exists(file_path):
            print(f"✅ Transcript already exists: {file_path}")
            return file_path
        
        # Get transcript
        transcripter = YouTubeTranscriptApi()
        
        try:
            # Try English first
            print("🔄 Trying to fetch English transcript...")
            transcript = transcripter.fetch(video_id, languages=target_lang_eng)
            
            data = [{
                "start": entry['start'],
                "text": entry['text'],
                "duration": entry['duration'],
            } for entry in transcript]
            
            with open(file_path, 'w', encoding='utf-8') as file:
                json.dump(data, file, indent=4, ensure_ascii=False)
            
            print(f"✅ English transcript saved: {file_path}")
            return file_path
            
        except Exception as e:
            print(f"⚠️ English transcript failed: {e}")
            
            try:
                # Try Hindi as fallback
                print("🔄 Trying to fetch Hindi transcript...")
                transcript = transcripter.fetch(video_id, languages=target_lang_hindi)
                
                data_hindi = [{
                    "start": entry['start'],
                    "text": entry['text'],
                    "duration": entry['duration'],
                } for entry in transcript]
                
                with open(file_path, 'w', encoding='utf-8') as file:
                    json.dump(data_hindi, file, indent=4, ensure_ascii=False)
                
                print(f"✅ Hindi transcript saved: {file_path}")
                return file_path
                
            except Exception as e2:
                print(f"⚠️ Hindi transcript also failed: {e2}")
                
                try:
                    # Try any available language
                    print("🔄 Trying to fetch transcript in any available language...")
                    transcript = transcripter.fetch(video_id)
                    
                    data_any = [{
                        "start": entry['start'],
                        "text": entry['text'],
                        "duration": entry['duration'],
                    } for entry in transcript]
                    
                    with open(file_path, 'w', encoding='utf-8') as file:
                        json.dump(data_any, file, indent=4, ensure_ascii=False)
                    
                    print(f"✅ Transcript saved in available language: {file_path}")
                    return file_path
                    
                except Exception as e3:
                    print(f"❌ All transcript methods failed: {e3}")
                    return None
    
    except Exception as e:
        print(f"❌ Complete YouTube transcript loading failed: {e}")
        return None


def downloading_transcript_youtube_video(url: str):
    """
    Wrapper function to maintain compatibility with your RAG engine
    """
    return youtube_transcript_loader(url)


# Test function
if __name__ == "__main__":
    test_url = "https://www.youtube.com/watch?v=dQw4w9WgXcQ"  # Replace with actual URL
    result = youtube_transcript_loader(test_url)
    print(f"Result: {result}")

# # fuction to load the transcript either in hindi or english 
# def youtube_transcript_loader(url:str):
#               target_lang_eng = ['en']
#               target_lang_hindi = ['hi']
#               video_id = extract_video_id(url)
#               transcripter = YouTubeTranscriptApi()
#               language_list_transcript = transcripter.list(video_id)
#               # checking language
#               for trans in language_list_transcript:
#                       try:
#                               if trans.language_code == "en":
#                                       transcript = transcripter.fetch(video_id, languages=target_lang_eng)
#                                       data = [{
#                                               "start": obj.start,
#                                               "text" : obj.text,
#                                               "duration": obj.duration,
#                                               }
#                                               for obj in transcript
#                                               ]
#                                       with open(f"/home/rachit/Desktop/VIDRAG PROJECT/data/raw/{video_id}", 'w') as file:
#                                               json.dump(data, file, indent= 4)
#                                               return "Transcript File Saved Successfully in English ✅"

                                              

#                               elif trans.language_code == "hi":
#                                       transcript = transcripter.fetch(video_id, languages=target_lang_hindi)
#                                       data_hindi = [{
#                                               "start": obj.start,
#                                               "text" : obj.text,
#                                               "duration": obj.duration,
#                                               }
#                                               for obj in transcript
#                                               ]
#                                       with open(f"/home/rachit/Desktop/VIDRAG PROJECT/data/raw/{video_id}", 'w') as file:
#                                               json.dump(data, file, indent= 4, ensure_ascii= False)
#                                               return "Transcript File Saved Successfully in Hindi ✅"

                            
#                       except Exception as e:
#                               return f"{Exception} could not fetch the transcript of the video because its language is neither english nor hindi"
                              

