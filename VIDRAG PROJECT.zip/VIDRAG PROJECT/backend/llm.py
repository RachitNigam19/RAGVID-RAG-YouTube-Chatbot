# backend/llm.py
from langchain_google_genai import GoogleGenerativeAIEmbeddings, ChatGoogleGenerativeAI
from langchain_huggingface import HuggingFaceEmbeddings
from transformers import pipeline
from dotenv import load_dotenv
import os

load_dotenv()

# Global flags to track API status
GEMINI_EMBEDDING_AVAILABLE = True
GEMINI_CHAT_AVAILABLE = True

def test_gemini_embeddings():
    """Test if Gemini embeddings are available"""
    global GEMINI_EMBEDDING_AVAILABLE
    try:
        api_key = os.getenv("GEMINI_API_KEY")
        if not api_key:
            GEMINI_EMBEDDING_AVAILABLE = False
            return False
        
        model = GoogleGenerativeAIEmbeddings(
            model="models/embedding-001",
            google_api_key=api_key
        )
        # Test with a very small text
        test_result = model.embed_documents(["test"])
        print("✅ Gemini embeddings are working")
        return True
    except Exception as e:
        print(f"❌ Gemini embeddings failed: {e}")
        GEMINI_EMBEDDING_AVAILABLE = False
        return False

def get_embedding_model():
    """Get embedding model with proper fallback"""
    global GEMINI_EMBEDDING_AVAILABLE
    
    # Try Gemini first only if we haven't detected quota issues
    if GEMINI_EMBEDDING_AVAILABLE:
        try:
            api_key = os.getenv("GEMINI_API_KEY")
            if api_key:
                model = GoogleGenerativeAIEmbeddings(
                    model="models/embedding-001",
                    google_api_key=api_key
                )
                # Quick test to see if it works
                model.embed_documents(["quick test"])
                print("✅ Using Gemini Embeddings")
                return model
        except Exception as e:
            print(f"❌ Gemini embeddings failed: {e}")
            GEMINI_EMBEDDING_AVAILABLE = False
    
    # Fallback to HuggingFace
    print("🔄 Falling back to HuggingFace embeddings...")
    try:
        model = HuggingFaceEmbeddings(
            model_name="sentence-transformers/all-MiniLM-L6-v2",
            model_kwargs={'device': 'cpu'},
            encode_kwargs={'normalize_embeddings': True}
        )
        print("✅ Using HuggingFace Embeddings")
        return model
    except Exception as e:
        print(f"❌ HuggingFace embeddings also failed: {e}")
        raise Exception("No embedding model available")

def get_chat_model():
    """Get chat model with proper fallback"""
    global GEMINI_CHAT_AVAILABLE
    
    # Try Gemini first
    if GEMINI_CHAT_AVAILABLE:
        try:
            api_key = os.getenv("GEMINI_API_KEY")
            if api_key:
                model = ChatGoogleGenerativeAI(
                    model="gemini-1.5-flash",
                    temperature=0.7,
                    google_api_key=api_key
                )
                # Quick test
                model.invoke("test")
                print("✅ Using Gemini Chat Model")
                return model
        except Exception as e:
            print(f"❌ Gemini chat failed: {e}")
            GEMINI_CHAT_AVAILABLE = False
    
    # Simple fallback - return a basic text generator
    print("🔄 Using basic text processing (no LLM)")
    return None  # We'll handle this in the retrieval function