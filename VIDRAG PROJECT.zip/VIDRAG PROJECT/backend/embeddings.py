# embedding logic for user query ---> vector conversion 
# embedding logic for document ---> vector conversion 
# importing dependencies 
from backend.llm import gemini_embedding_model_query
from backend.llm import gemini_embedding_model_document
from backend.llm import opensource_embedding_model_query
from backend.llm import opensource_embedding_model_document
from dotenv import load_dotenv
# without input of the docs 
from langchain_google_genai.embeddings import GoogleGenerativeAIEmbeddings
from langchain_huggingface.embeddings import HuggingFaceEmbeddings, HuggingFaceEndpointEmbeddings

load_dotenv()

# query gemini + opensource fallback 
def embedding_generation_gemOS_fb_query(query:str) -> list[float]:
              try:
                      try:
                              response_query_embeddings = gemini_embedding_model_query(query)
                              return response_query_embeddings
                      except:
                              response_query_embeddings = opensource_embedding_model_query(query)
                              return response_query_embeddings
              except Exception as e:
                      raise RuntimeError(f"Document embedding failed on both Gemini & Opensource: {e}")
              
def embeddings_generation_gemOS_fb_document(doc:list[str]) -> list[float]:
              try:
                      try:
                              vector_doc_embeddings = gemini_embedding_model_document(doc)
                              return vector_doc_embeddings
                      except Exception as e:
                              vector_doc_embeddings = opensource_embedding_model_document(doc)
                              return vector_doc_embeddings
              except Exception as e:
                      raise RuntimeError(f"Document Embeddding Failed for both Opensource and Gemini model, {e} ")

# def embeddings_generation_gemOS_fb_document():
#         try:
#                 try:
#                         vector_doc_embeddings = GoogleGenerativeAIEmbeddings(model="models/embedding-001")
#                         return vector_doc_embeddings
#                 except Exception as e:
#                         vector_doc_embeddings = opensource_embedding_model_document()
#                         return vector_doc_embeddings
#         except Exception as e:
#                 raise RuntimeError(f"Document Embeddding Failed for both Opensource and Gemini model, {e} ")