# # RAG Engine
# # importing dependencies 
# from langchain_core.runnables import RunnableSequence
# from data.embeddings.Knowledge_base_embeddings_store import knowledge_base_embeddings
# from backend.youtube import extract_video_id, youtube_transcript_loader
# from data.Retrieval.retieval import retreival_from_Knowledge_base
# # Chaining for the RAG

# backend/rag_engine.py
from backend.youtube import downloading_transcript_youtube_video
from data.Retrieval.retieval import retreival_from_Knowledge_base, simple_retrieval_from_knowledge_base
import os

def chaining(youtube_url: str, query: str):
    """
    Main RAG pipeline with robust error handling
    1. Download YouTube transcript
    2. Perform retrieval and generation
    """
    
    try:
        # Step 1: Download YouTube transcript
        print("🔄 Step 1: Downloading YouTube transcript...")
        video_path = downloading_transcript_youtube_video(youtube_url)
        
        if not video_path or not os.path.exists(video_path):
            return "❌ Failed to download or process the YouTube video transcript."
        
        print(f"✅ Transcript downloaded to: {video_path}")
        
        # Step 2: Try advanced retrieval first
        print("🔄 Step 2: Attempting advanced retrieval...")
        try:
            response = retreival_from_Knowledge_base(query, video_path)
            
            # Check if response indicates an error
            if "❌" in response and "Could not process" in response:
                raise Exception("Advanced retrieval failed")
                
            return response
            
        except Exception as e:
            print(f"⚠️ Advanced retrieval failed: {e}")
            print("🔄 Falling back to simple retrieval...")
            
            # Step 3: Fallback to simple retrieval
            try:
                response = simple_retrieval_from_knowledge_base(query, video_path)
                return response
            except Exception as e2:
                print(f"⚠️ Simple retrieval also failed: {e2}")
                return f"❌ I'm having trouble processing this video right now. Error details: {str(e2)}"
    
    except Exception as e:
        print(f"❌ Complete pipeline failure: {e}")
        return f"❌ Something went wrong with the entire process. Please check the YouTube URL and try again. Error: {str(e)}"

# def chaining(youtube_url: str, query: str):
#     """
#     End-to-end RAG pipeline:
#     1. Download YouTube transcript & save as JSON
#     2. Build Knowledge Base embeddings
#     3. Retrieve + generate response from LLM
#     """

#     try:
#         # 1. Load transcript of the YouTube video and save as JSON
#         youtube_transcript_loader(youtube_url)

#         # 2. Fetch video_id for transcript file path
#         video_id = extract_video_id(youtube_url)
#         path_json_transcript = f"/home/rachit/Desktop/VIDRAG PROJECT/data/raw/{video_id}"

#         # 3. Call retrieval pipeline with query + path
#         response = retreival_from_Knowledge_base(
#             query=query,
#             path=path_json_transcript
#         )

#         # 4. Return final LLM answer
#         return response

#     except Exception as e:
#         raise RuntimeError(
#             f"❌ Could not process your request right now! Please try again later.\nDetails: {e}"
#         )


