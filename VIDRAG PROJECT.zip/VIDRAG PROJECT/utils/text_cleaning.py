# text chunking and cleaning function's logic
from langchain.text_splitter import RecursiveCharacterTextSplitter # most used in industry

# logic for loading -> splitting
def text_splitting_recursive_char(doc):
              """Text Splitting for the document (Transcripts)"""
              splitter = RecursiveCharacterTextSplitter(
                      chunk_size = 1000,
                      chunk_overlap = 100 
              )
              chunked_documents = splitter.split_documents(doc)
              print(f"Document Chunked Successfully! Chunk Size: {len(chunked_documents)}")
              return chunked_documents
