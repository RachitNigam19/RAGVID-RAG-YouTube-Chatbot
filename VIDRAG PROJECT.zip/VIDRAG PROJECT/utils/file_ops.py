# # files i/o logic 
# # importing dependencies 
# import json # majorly we will work with json
# from langchain_community.document_loaders import JSONLoader
# import os

# utils/file_ops.py
from langchain.schema import Document
import json
import os

def langchain_json_file_loader(file_path: str):
    """
    Load JSON transcript file and convert to LangChain Document format
    
    Args:
        file_path: Path to the JSON transcript file
    
    Returns:
        List of Document objects
    """
    try:
        # Check if file exists
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"Transcript file not found: {file_path}")
        
        # Read JSON file
        with open(file_path, 'r', encoding='utf-8') as file:
            transcript_data = json.load(file)
        
        # Validate data format
        if not isinstance(transcript_data, list):
            raise ValueError("Transcript data should be a list")
        
        # Create Document objects
        documents = []
        
        # Group transcript entries (you can adjust chunk size as needed)
        chunk_size = 10  # Number of transcript entries per document
        
        for i in range(0, len(transcript_data), chunk_size):
            chunk = transcript_data[i:i + chunk_size]
            
            # Create page content as JSON string
            page_content = json.dumps(chunk)
            
            # Extract video ID from file path
            video_id = os.path.basename(file_path)
            
            # Create document
            doc = Document(
                page_content=page_content,
                metadata={
                    "source": file_path,
                    "video_id": video_id,
                    "seq_num": i // chunk_size,
                    "chunk_size": len(chunk),
                    "start_time": chunk[0].get("start", 0) if chunk else 0,
                    "end_time": chunk[-1].get("start", 0) + chunk[-1].get("duration", 0) if chunk else 0
                }
            )
            documents.append(doc)
        
        print(f"✅ Loaded {len(documents)} document chunks from {file_path}")
        return documents
        
    except Exception as e:
        print(f"❌ Error loading JSON file {file_path}: {e}")
        raise


def simple_json_loader(file_path: str):
    """
    Simple JSON file loader for debugging
    """
    try:
        with open(file_path, 'r', encoding='utf-8') as file:
            data = json.load(file)
        return data
    except Exception as e:
        print(f"❌ Error loading JSON: {e}")
        return None


# # for json file loading using langchain-json-loader
# def langchain_json_file_loader(path:str):
#               """Load json file and return the data"""
#               try:
#                      json_loader = JSONLoader(file_path=path, jq_schema=".", text_content= False)
#                      loader = json_loader.load()
#                      return loader
                     
#               except Exception as e:
#                      return(f"{e}")
                    

# # path = "/home/rachit/Desktop/VIDRAG PROJECT/data/raw/RfLFomlc_-Y"
# # print(langchain_json_file_loader(path))

# # json file loading through file handling 
# def json_file_loading(path: str):
#     """Load JSON file and return the data."""
#     try:
#         with open(path, 'r', encoding='utf-8') as file:
#             data = json.load(file)
#         return data
#     except FileNotFoundError:
#         print(f"File not found: {path}")
#         return None
#     except json.JSONDecodeError:
#         print(f"Invalid JSON file: {path}")
#         return None

# # save json file
# def save_dict_json_file(input_dict:dict):
#     """Save Json File from dictionary"""
#     path = os.path("/home/rachit/Desktop/VIDRAG PROJECT/data/raw")
#     try:
#           if os.path.exists(path):
#                 # save a json file
#                 with open (path, 'w', encoding='utf-8') as file:
#                       json.dump(input_dict, file, ensure_ascii=True, indent=4)
#                       print(f"Successfully JSON File Saved! at {path}")
#                       return True
#     except Exception as e:
#           print(f"Error Saving in json File!: {e}")
#           return False
    
# #     for entry in loaded_file:
# #         # page_content is a stringified JSON list
# #         transcript = json.loads(entry.page_content)   # ab list[dict] ban gaya
        
# #         for line in transcript:  # line = {"start": ..., "text": ..., "duration": ...}
# #             docs.append(
# #                 Document(
# #                     page_content=line["text"],     # ✅ ab directly text milega
# #                     metadata={
# #                         "start_time": line["start"],
# #                         "duration": line["duration"],
# #                         "video_id": entry.metadata["source"].split("/")[-1],
# #                         "seq_num": entry.metadata.get("seq_num")
# #                     }
# #                 )
# #             )



          
