import logging

# Logger object
logger = logging.getLogger("my_app_logger")
logger.setLevel(logging.INFO)  # INFO, DEBUG, WARNING, ERROR

# File handler
file_handler = logging.FileHandler("app.log")  # Ye file automatically create hogi
file_handler.setLevel(logging.INFO)

# Formatter
formatter = logging.Formatter("%(asctime)s - %(levelname)s - %(message)s")
file_handler.setFormatter(formatter)

# Add handler if not already added
if not logger.hasHandlers():
    logger.addHandler(file_handler)
