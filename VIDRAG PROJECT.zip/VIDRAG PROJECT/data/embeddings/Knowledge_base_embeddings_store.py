# data/embeddings/Knowledge_base_embeddings_store.py
from langchain.schema import Document
from utils.file_ops import langchain_json_file_loader
from utils.text_cleaning import text_splitting_recursive_char
from langchain_community.vectorstores import FAISS
from backend.llm import get_embedding_model
import json
import os
import asyncio
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# ✅ Asyncio Event Loop Fix
try:
    asyncio.get_event_loop()
except RuntimeError:
    asyncio.set_event_loop(asyncio.new_event_loop())

# Cache for vector stores to avoid recreating
_vector_store_cache = {}

def knowledge_base_embeddings(path: str):
    """
    Loads transcript JSON -> Converts into Document -> Splits -> 
    Embeds (Gemini / fallback HuggingFace) -> Saves FAISS -> Returns Vector Store
    """
    
    # Check if we already have this vector store in cache
    if path in _vector_store_cache:
        print(f"✅ Using cached vector store for {path}")
        return _vector_store_cache[path]

    # 1. Load transcript JSON
    loaded_file = langchain_json_file_loader(path)
    print(f"📂 Json file Loaded Successfully for Generating Embeddings! {path}")

    # 2. Convert JSON into LangChain Document objects
    docs = []
    for entry in loaded_file:
        transcript = json.loads(entry.page_content)   # list[dict]
        full_text = " ".join([line["text"] for line in transcript])  # join all text
        docs.append(
            Document(
                page_content=full_text,
                metadata={
                    "video_id": entry.metadata["source"].split("/")[-1],
                    "seq_num": entry.metadata.get("seq_num")
                }
            )
        )
    print("✅ Converted into Document objects")

    # 3. Chunking documents
    chunkings = text_splitting_recursive_char(docs)
    print("✅ Document Chunked")

    # 4. Get embedding model with proper fallback
    try:
        embeddings_model = get_embedding_model()
    except Exception as e:
        print(f"❌ Failed to get any embedding model: {e}")
        raise

    # 5. Create FAISS vector store with retry logic
    max_retries = 3
    for attempt in range(max_retries):
        try:
            print(f"🔄 Creating FAISS vector store (attempt {attempt + 1}/{max_retries})...")
            
            # Process in smaller batches to avoid quota issues
            batch_size = 10
            all_docs = []
            
            for i in range(0, len(chunkings), batch_size):
                batch = chunkings[i:i + batch_size]
                print(f"📦 Processing batch {i//batch_size + 1}/{(len(chunkings) + batch_size - 1)//batch_size}")
                
                if i == 0:
                    # Create initial vector store with first batch
                    knowledge_base_vector_store = FAISS.from_documents(
                        batch, 
                        embedding=embeddings_model
                    )
                else:
                    # Add subsequent batches
                    batch_store = FAISS.from_documents(batch, embedding=embeddings_model)
                    knowledge_base_vector_store.merge_from(batch_store)
                
                # Small delay to respect rate limits
                import time
                time.sleep(1)
            
            print("✅ FAISS Vector Store Created")
            
            # Cache the vector store
            _vector_store_cache[path] = knowledge_base_vector_store
            return knowledge_base_vector_store
            
        except Exception as e:
            print(f"⚠️ Attempt {attempt + 1} failed: {e}")
            if attempt < max_retries - 1:
                print("🔄 Retrying with different approach...")
                # Try to get a fresh embedding model
                try:
                    embeddings_model = get_embedding_model()
                except:
                    pass
            else:
                print("❌ All attempts failed, using simple text matching fallback")
                raise

    raise Exception("Failed to create vector store after all retries")


# Simple fallback function for when embeddings fail completely
def create_simple_text_store(path: str):
    """
    Create a simple text-based search without embeddings
    """
    try:
        loaded_file = langchain_json_file_loader(path)
        docs = []
        
        for entry in loaded_file:
            transcript = json.loads(entry.page_content)
            full_text = " ".join([line["text"] for line in transcript])
            docs.append(Document(page_content=full_text))
        
        print(f"✅ Created simple text store with {len(docs)} documents")
        return docs
    except Exception as e:
        print(f"❌ Even simple text store failed: {e}")
        return []


# Debug Run (Direct file test)
if __name__ == "__main__":
    test_path = "/home/rachit/Desktop/VIDRAG PROJECT/data/raw/RfLFomlc_-Y"
    try:
        result = knowledge_base_embeddings(test_path)
        print(f"Success: {result}")
    except Exception as e:
        print(f"Failed: {e}")
        # Try simple fallback
        simple_result = create_simple_text_store(test_path)
        print(f"Simple fallback: {len(simple_result)} documents")