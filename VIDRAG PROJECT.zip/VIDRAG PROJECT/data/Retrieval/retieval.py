# backend/rag_engine.py
from backend.youtube import youtube_transcript_loader  # Fixed: use correct function name
from data.Retrieval.retrieval import retreival_from_Knowledge_base, simple_retrieval_from_knowledge_base  # Fixed: correct file name
from backend.rag_engine_offlin import offline_chaining  # Added: missing import
import os

def chaining(youtube_url: str, query: str):
    """
    Main RAG pipeline with robust error handling
    1. Download YouTube transcript
    2. Perform retrieval and generation
    """
    
    try:
        # Step 1: Download YouTube transcript
        print("🔄 Step 1: Downloading YouTube transcript...")
        video_path = youtube_transcript_loader(youtube_url)  # Fixed: correct function name
        
        if not video_path or not os.path.exists(video_path):
            return "❌ Failed to download or process the YouTube video transcript."
        
        print(f"✅ Transcript downloaded to: {video_path}")
        
        # Step 2: Try advanced retrieval first
        print("🔄 Step 2: Attempting advanced retrieval...")
        try:
            response = retreival_from_Knowledge_base(query, video_path)
            
            # Check if response indicates an API quota error
            if "429" in response or "quota" in response.lower() or "rate limit" in response.lower():
                raise Exception("API quota exceeded")
                
            # Check if response indicates other API errors
            if "❌" in response and ("Could not process" in response or "Error" in response):
                raise Exception("Advanced retrieval failed")
                
            return response
            
        except Exception as e:
            print(f"⚠️ Advanced retrieval failed: {e}")
            
            # If it's a quota error, skip to offline mode
            if "429" in str(e) or "quota" in str(e).lower():
                print("🔄 API quota exceeded, switching to offline mode...")
                return offline_chaining(youtube_url, query)
            
            print("🔄 Falling back to simple retrieval...")
            
            # Step 3: Try simple retrieval
            try:
                response = simple_retrieval_from_knowledge_base(query, video_path)
                
                if "❌" in response or "Error" in response:
                    raise Exception("Simple retrieval failed")
                    
                return response
                
            except Exception as e2:
                print(f"⚠️ Simple retrieval also failed: {e2}")
                print("🔄 Switching to offline mode...")
                
                # Step 4: Use completely offline approach
                return offline_chaining(youtube_url, query)
    
    except Exception as e:
        print(f"❌ Complete pipeline failure: {e}")
        return f"❌ Something went wrong with the entire process. Please check the YouTube URL and try again. Error: {str(e)}"


# Test function for debugging
def test_rag_engine():
    """Test function to debug the RAG engine"""
    test_url = "https://www.youtube.com/watch?v=dQw4w9WgXcQ"  # Replace with actual URL
    test_query = "What is this video about?"
    
    result = chaining(test_url, test_query)
    print(f"Test Result: {result}")


if __name__ == "__main__":
    test_rag_engine()